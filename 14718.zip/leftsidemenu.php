      <aside class="main-sidebar" 
        <section class="sidebar" > 
          <ul class="sidebar-menu">
            <li class="treeview"><a href="loggeduserhome"><i class="fa fa-home" ></i> <span>Home</span></a></li>
			

			<li class="treeview active"> <a ><i class="fa fa-th"></i><span>Masters</span><i class="fa fa-angle-right pull-right"></i></a>
              <ul class="treeview-menu">
				<li><a href="prog_control.php?p_nm=Company Master"><i class="fa fa-sitemap" ></i> <span>Company</span></a></li>			  
				<li><a href="prog_control.php?p_nm=Application User Registration"><i class="fa fa-user-plus"></i> User Master</a></li>	
				<li><a href="prog_control.php?p_nm=Gang Code Master"><i class="fa fa-user-secret"></i> Gang Code</a></li>	
				<li><a href="prog_control.php?p_nm=Commodity Master"><i class="fa fa-toggle-off"></i> Commodity</a></li>	
				<li><a href="prog_control.php?p_nm=Vessel Master"><i class="fa fa-shield"></i> Vessel</a></li>	
				<li><a href="prog_control.php?p_nm=Work Type Master"><i class="fa fa-history"></i> Work Type</a></li>	
				<li><a href="prog_control.php?p_nm=Casual Labour Rate Master"><i class="fa fa-user-secret"></i> Casual Labour Rate</a></li>	
				<li><a href="prog_control.php?p_nm=Financial Year"><i class="fa fa-user-secret"></i> Financial Acc Year</a></li>	
				
				</ul>
			<li class="treeview active"> <a ><i class="fa fa-th"></i><span>Transactions</span><i class="fa fa-angle-right pull-right"></i></a>
				<ul class="treeview-menu">
                <li><a href="prog_control.php?p_nm=Advance Payment"><i class="fa fa-university"></i> Advance Payment</a></li>
				<li><a href="prog_control.php?p_nm=Balance Process"><i class="fa fa-history"></i> Create Outstanding</a></li>
				<li><a href="prog_control.php?p_nm=Advance Outstanding"><i class="fa fa-history"></i> Outstanding View</a></li>
				<li><a href="prog_control.php?p_nm=Advance Deduction"><i class="fa fa-history"></i> Authorized Deduction</a></li> 
				<li><a href="prog_control.php?p_nm=Daily Challan"><i class="fa fa-history"></i> Daily Challan</a></li>
				<li><a href="prog_control.php?p_nm=Process Pay roll"><i class="fa fa-history"></i> Reserved</a></li>	
				<li><a href="prog_control.php?p_nm=Pay Roll master list"><i class="fa fa-history"></i>  Pay Roll master list</a></li>
                <li><a href="prog_control.php?p_nm=Pay Roll statement-1 "><i class="fa fa-history"></i> Pay Roll statement1 </a></li>
              </ul>
            </li>
          </ul>
        </section>
      </aside>