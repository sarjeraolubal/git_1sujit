	<form id="salarymetadata"  class="form-horizontal"  name="salarymetadata" method="post" enctype="multipart/form-data" action="salarymetadata_ss.php">


		<button type="submit" name="submit" class="btn btn-success">Search&nbsp;<i class="fa fa-search"></i></button>
	</form>
