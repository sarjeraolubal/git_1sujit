	<form id="itrate"  class="form-horizontal"  name="itrate" method="post" enctype="multipart/form-data" action="itrate_ss.php">


		<button type="submit" name="submit" class="btn btn-success">Search&nbsp;<i class="fa fa-search"></i></button>
	</form>
