	<form id="salarycalculationformula"  class="form-horizontal"  name="salarycalculationformula" method="post" enctype="multipart/form-data" action="salarycalculationformula_ss.php">


		<button type="submit" name="submit" class="btn btn-success">Search&nbsp;<i class="fa fa-search"></i></button>
	</form>
