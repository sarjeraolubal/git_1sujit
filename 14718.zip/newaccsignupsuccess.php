<?php 

$error_message = '';
require 'dist/lib/commonfunc.php';

include "dist/inc/nonloginheader.php";?>


<div class="container" style="min-height:500px;">
<div id="loginbox" style="margin-top:50px;" class="mainbox col-md-4 col-md-offset-3 col-sm-8 col-sm-offset-2">     
<div class="panel panel-info" >

<div style="padding-top:30px" class="panel-body" >

<p><img src="dist/img/success-icon.png">&nbsp;&nbsp;Registration completed successfuly !! Click <a href="index.php" title="">here</a> for login</p>

</div>  
</div>
</div> 	  
</div> <!-- /container -->

<?php include "dist/inc/footercontent.php";?>