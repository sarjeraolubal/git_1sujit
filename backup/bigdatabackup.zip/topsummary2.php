			  
          <!-- Small boxes (Stat box) -->
          <div class="row">
           
            <div class="col-lg-6">
              <!-- small box -->
              <div class="small-box bg-yellow">
                <div class="inner">
                  <h3><?php echo !empty($v_rm_stock_closebal)?$v_rm_stock_closebal:'0';?> SW</h3>
                  <p>Authorised to use</p>
                </div>
                <div class="icon">
                  <i class="ion ion-soup-can"></i>
                </div>
                <a href="#" class="small-box-footer">Add More <i class="fa fa-plus"></i></a>
              </div>
            </div><!-- ./col -->
			
               <div class="col-lg-6">
              <!-- small box -->
              <div class="small-box bg-yellow">
                <div class="inner">
                  <h3><?php echo !empty($v_prod_stock_closebal)?$v_prod_stock_closebal:'0';?> Appl</h3>
                  <p>License/AMC to be renewed</p>
                </div>
                <div class="icon">
                  <i class="ion ion-cube"></i>
                </div>
                <a href="#" class="small-box-footer">Renew Now <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
		  
	
          </div><!-- /.row -->			  