	<form id="salaryratemaster"  class="form-horizontal"  name="salaryratemaster" method="post" enctype="multipart/form-data" action="salaryratemaster_ss.php">


		<button type="submit" name="submit" class="btn btn-success">Search&nbsp;<i class="fa fa-search"></i></button>
	</form>
