<div class="content-wrapper" style="margin:0;background:none" >

<div class="col-md-16">
<p style="color:white;margin:45px;font-size:18px;">We brings list of valuable, powerful software for your business at lower than affordable price. We assure you it will add values to your organization. Call for a demo or register to use now.<br>
License FREE business applications, pay only AMC (Annual Maintenance Contract).</p>
</div>
<div style="margin:30px">
<div class="col-md-2">
	<a href="#" title="Core Banking"> <img src="dist/img/swapp/docmgmt.jpg" width="200px" height="130px"/></a>
	<p style="color:white;">Document Management</p>
</div>
<div class="col-md-2">
	<a href="#" title="Inventory"> <img src="dist/img/swapp/computerservice.jpg" width="200px" height="130px"/></a>
	<p style="color:white;">Computer Services & Repair</p>
</div>
<div class="col-md-2">
	<a href="#" title="Inventory"> <img src="dist/img/swapp/Inventory_Mgmt.jpg" width="200px" height="130px"/></a>
	<p style="color:white;">Product/Raw Material Inventory</p>
</div>

<div class="col-md-2">
	<a href="#" title="Inventory"> <img src="dist/img/swapp/Marine-Engineering.jpg" width="200px" height="130px"/></a>
	<p style="color:white;">Engineering Service Mgmt</p>
</div>

<div class="col-md-2">
	<a href="#" title="Inventory"> <img src="dist/img/swapp/electronicservice.png" width="200px" height="130px"/></a>
	<p style="color:white;">Electronic Services Mgmt</p>
</div>


<div class="col-md-2">
	<a href="#" title="Inventory"> <img src="dist/img/swapp/goodstransport.jpg" width="200px" height="130px"/></a>
	<p style="color:white;">Goods Transport Management</p>
</div>

<div class="col-md-2">
	<a href="#" title="Inventory"> <img src="dist/img/swapp/EducationManagement_1.jpg" width="200px" height="130px"/></a>
	<p style="color:white;">Education Management</p>
</div>

<div class="col-md-2">
	<a href="#" title="Inventory"> <img src="dist/img/swapp/marketing.jpg" width="200px" height="130px"/></a>
	<p style="color:white;">Product Marketing</p>
</div>

<div class="col-md-2">
	<a href="#" title="Inventory"> <img src="dist/img/swapp/threadmanufact.jpg" width="200px" height="130px"/></a>
	<p style="color:white;">Product Manufacturing</p>
</div>
<div class="col-md-2">
	<a href="#" title="Inventory"> <img src="dist/img/swapp/learning.jpg" width="200px" height="130px"/></a>
	<p style="color:white;">Learning Management</p>
</div>
<div class="col-md-2">
	<a href="#" title="Inventory"> <img src="dist/img/swapp/licence.png" width="200px" height="130px"/></a>
	<p style="color:white;">License Tracking</p>
</div>
<div class="col-md-2">
	<a href="#" title="Inventory"> <img src="dist/img/swapp/payroll.jpg" width="200px" height="130px"/></a>
	<p style="color:white;">Payroll Management</p>
</div>
<div class="col-md-2">
	<a href="#" title="Inventory"> <img src="dist/img/swapp/candidateprofile.jpg" width="200px" height="130px"/></a>
	<p style="color:white;">Candidate Profiling & Interview</p>
</div>
<div class="col-md-2">
	<a href="#" title="Inventory"> <img src="dist/img/swapp/attendance.jpg" width="200px" height="130px"/></a>
	<p style="color:white;">Attendance Tracking</p>
</div>

<div class="col-md-2">
	<a href="#" title="Inventory"> <img src="dist/img/swapp/finaccounting.jpg" width="200px" height="130px"/></a>
	<p style="color:white;">Financial Accounting</p>
</div>



<div class="col-md-2">
	<a href="#" title="Inventory"> <img src="dist/img/swapp/digipos.jpg" width="200px" height="130px"/></a>
	<p style="color:white;">Digital POS</p>
</div>

<div class="col-md-2">
	<a href="#" title="Inventory"> <img src="dist/img/swapp/operationalreport.jpg" width="200px" height="130px"/></a>
	<p style="color:white;">Operational Report & Enquiry</p>
</div>

<div class="col-md-2">
	<a href="#" title="Inventory"> <img src="dist/img/swapp/healthreport.jpg" width="200px" height="130px"/></a>
	<p style="color:white;">Health & Life Style Tracking</p>
</div>


<div class="clearfix"></div>
<br>





</div>
<div class="clearfix"></div>

</div>
